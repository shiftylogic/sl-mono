#include <doctest.h>

TEST_CASE("hash_char_types") {
    // TODO(martinus) make hash generic?
    // REQUIRE(123 != ankerl::hash<wchar_t>{}(123));
}
