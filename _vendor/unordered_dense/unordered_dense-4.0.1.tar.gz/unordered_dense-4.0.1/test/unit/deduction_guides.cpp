#include <doctest.h> // for TestCase, skip, TEST_CASE, test_...

TEST_CASE("deduction_guide") {
    // TODO(martinus) not yet possible, only in c++20. See
    // https://stackoverflow.com/a/41008415
    // https://en.cppreference.com/w/cpp/language/class_template_argument_deduction
}